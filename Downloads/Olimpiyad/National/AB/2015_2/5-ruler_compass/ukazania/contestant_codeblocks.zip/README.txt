﻿За да работите с Code::Blocks:
  1. Отворете файла ruler_compass.cbp с Code::Blocks
  2. В Code::Blocks, от менюто с проектите, изберете проекта
ruler_compass, и от Sources, отворете ruler_compass.cpp
  3. Редактирайте, и компилирайте както обикновено
с натискане на F9.
  4. Изпълнимия файл се генерира в папката bin/Debug/
